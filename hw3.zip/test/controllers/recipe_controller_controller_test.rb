require 'test_helper'

class RecipeControllerControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
