Rails.application.routes.draw do
  get 'courses/index'

  # get 'greeter/hello'

  # SAME AS ABOVE
  get 'greeter/hello' => "greeter#hello"
  get 'greeter/goodbye'
  get 'recipes/index' => "recipes#index"
  get 'recipes' => "recipes#index"
  #get 'recipes' =>"recipes#index"
  root 'recipes#index'
  #get 'recipes' => "recipes#index"
  # You can have the root of your site routed with "root"
  # root 'welcome#index'
end
